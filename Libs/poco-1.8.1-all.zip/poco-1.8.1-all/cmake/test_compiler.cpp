#include <iostream>
#include <string>

int main()
{
  std::string str = "Try to compile";
  std::cout << str << '\n';
  return 0;
}
